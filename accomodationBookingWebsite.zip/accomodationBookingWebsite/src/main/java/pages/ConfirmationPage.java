package pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import base.TestBase;

public class ConfirmationPage extends TestBase {

	// Objects
	@FindBy(xpath = "//*[@class='btn btn-outline-primary']")
	WebElement confirmclosebtn;

	@FindBy(xpath = "//*[text()='Booking Successful!']")
	WebElement confirmationpopup;

	// Initializing the Page Objects:
	public ConfirmationPage() throws IOException {
		PageFactory.initElements(driver, this);
	}

	// Actions:
	public BookingPage validateConfirmCloseBtn() throws IOException {
		Assert.assertTrue(confirmationpopup.isDisplayed(), "Booking confirmation message is not displayed.");
		confirmclosebtn.click();
		return new BookingPage();
	}
}
