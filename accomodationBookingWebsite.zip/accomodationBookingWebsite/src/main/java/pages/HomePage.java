package pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import base.TestBase;

public class HomePage extends TestBase {
        
	//Objects
	@FindBy(xpath="//*[@class='btn btn-primary']")
	WebElement letmehackbtn;
	
	@FindBy(xpath="//*[@class='btn btn-outline-primary float-right openBooking']")
	WebElement bookthisroom;
	
	//Initializing the Page Objects:
	public HomePage() throws  IOException{
		PageFactory.initElements(driver, this);
	}
		
	//Actions:
	public BookingPage validateBookThisRoom() throws IOException {
		
		letmehackbtn.click();
		Assert.assertTrue(bookthisroom.isDisplayed(), "Room details are not displayed.");
		bookthisroom.click();
		
		return new BookingPage();
	} 
}

