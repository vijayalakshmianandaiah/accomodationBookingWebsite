package pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import base.TestBase;

public class BookingPage extends TestBase {
	
	
	//Objects
	
		@FindBy(name="firstname")
		WebElement firstname;
		
		@FindBy(name="lastname")
		WebElement lastname;
		
		@FindBy(name="email")
		WebElement email;
		
		@FindBy(name="phone")
		WebElement phone;
		
		//@FindBy(xpath="//*[@class='rbc-day-bg rbc-today']")
		@FindBy(xpath="(//div[contains(@class, 'rbc-day-bg')])[22]")
		WebElement startdate;
		
		//@FindBy(xpath="//*[@class='rbc-day-bg rbc-today']//following-sibling::div[2]")
		@FindBy(xpath="(//div[contains(@class, 'rbc-day-bg')])[24]")
		WebElement enddate;
		
		@FindBy(xpath="//*[@class='btn btn-outline-primary float-right book-room']")
		WebElement bookbtn;
		
		@FindBy(xpath="//*[@class='rbc-event-content' and text()='Unavailable']")
		WebElement unavailablebtn;
		
	//Initializing the Page Objects

		public BookingPage() throws  IOException{
			PageFactory.initElements(driver, this);
		}
			
	//Actions:
		
		public ConfirmationPage validateConfirmationBooking() throws IOException {
			
			Assert.assertTrue(startdate.isDisplayed(), "Booking calendar is not visible.");
			
			Actions action=new Actions(driver);
			action.click(startdate).clickAndHold(enddate).dragAndDrop(startdate, enddate).build().perform();
						
			firstname.sendKeys("test");
			lastname.sendKeys("test");
			email.sendKeys("test@test.com");
			phone.sendKeys("12345678901");
			Assert.assertTrue(bookbtn.isEnabled(), "Book button is not enabled.");
			
			bookbtn.click();
						
			return new ConfirmationPage();
		} 

}
