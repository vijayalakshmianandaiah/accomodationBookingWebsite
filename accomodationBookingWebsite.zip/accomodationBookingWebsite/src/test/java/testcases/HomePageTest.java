package testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import base.TestBase;
import pages.BookingPage;
import pages.HomePage;

public class HomePageTest extends TestBase {

	HomePage homePage;
	BookingPage bookingPage;

	public HomePageTest() throws IOException {
		super();
	}

	@BeforeMethod
	public void setup() throws IOException {
		initialization();
		homePage=new HomePage();
		Assert.assertTrue(driver.getTitle().contains("Restful-booker-platform demo"), "Page did not load correctly.");
	}

	@Test
	public void clickOnBookThisRoomBtnTest() throws IOException {
		bookingPage = homePage.validateBookThisRoom();
	
	}
}