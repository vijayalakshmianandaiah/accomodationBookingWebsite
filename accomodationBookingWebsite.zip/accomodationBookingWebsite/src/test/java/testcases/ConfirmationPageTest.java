package testcases;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import base.TestBase;
import pages.BookingPage;
import pages.ConfirmationPage;
import pages.HomePage;

public class ConfirmationPageTest extends TestBase {

	HomePage homePage;
	BookingPage bookingPage;
	ConfirmationPage confirmationPage;

	public ConfirmationPageTest() throws IOException {
		super();
	}

	@Test
	public void clickOnConfirmCloseBtnTest() throws IOException {
		confirmationPage = new ConfirmationPage();
		bookingPage = confirmationPage.validateConfirmCloseBtn();
	}
	
	@AfterMethod
	public void teardown() {
		driver.quit();
	}
}


