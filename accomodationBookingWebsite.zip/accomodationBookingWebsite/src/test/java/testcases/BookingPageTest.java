package testcases;

import java.io.IOException;

import org.testng.annotations.Test;

import base.TestBase;
import pages.BookingPage;
import pages.ConfirmationPage;
import pages.HomePage;

public class BookingPageTest extends TestBase {

	HomePage homePage;
	BookingPage bookingPage;
	ConfirmationPage confirmationPage;

	public BookingPageTest() throws IOException {
		super();
	}

	@Test
	public void clickOnBookBtnTest() throws IOException {
		bookingPage = new BookingPage();
		confirmationPage = bookingPage.validateConfirmationBooking();
	}

}
